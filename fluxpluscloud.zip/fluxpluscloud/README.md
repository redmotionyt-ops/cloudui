# Flux+ Cloud Suite

This package contains three parts:

- `frontend/` → website UI for `cloud.fluxplus.in`
- `backend/` → VPS backend API and static frontend host
- `donor/` → donor storage agent with its own tiny file server

## Core flow

- Admin logs in with the passcode from `.env`
- Admin creates donors and API keys from the UI
- Donor agent connects using `donorId` + `donorKey`
- Daemon uploads backups through the backend API using an API key
- Donor stores files on its own disk
- Website downloads and daemon restore downloads are streamed through the backend from the donor file server

## Run backend

From `backend/`:

```bash
npm install
cp ../.env.example .env
npm start
```

Open `http://localhost:3000`

## Run donor

From `donor/`:

```bash
cp config.example.json config.json
npm start
```

Before starting the donor, add a donor from the cloud UI and copy the generated `donorKey` into `config.json`.

## Important folders

- `data/state.json` → persistent JSON database
- `data/uploads-temp/` → temporary staged uploads before donor fetches them

## Default passcode

`Fluxcloudadmin112233445`

Change it in `.env`.

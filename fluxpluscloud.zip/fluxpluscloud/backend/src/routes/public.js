import { Router } from 'express';
import { requireAdmin } from '../lib/security.js';
import { readState } from '../lib/store.js';
import { bytesToHuman, maskSecret } from '../lib/utils.js';
import { computeDonor } from '../lib/donors.js';

const router = Router();

router.get('/dashboard', requireAdmin, (_req, res) => {
  const state = readState();

  const donors = (state.donors || []).map(computeDonor).map((donor) => ({
    ...donor,
    donorKeyMasked: maskSecret(donor.donorKey || ''),
    totalHuman: bytesToHuman(donor.system?.totalBytes || 0),
    freeHuman: bytesToHuman(donor.system?.freeBytes || 0),
    usedHuman: bytesToHuman((donor.system?.totalBytes || 0) - (donor.system?.freeBytes || 0))
  }));

  const backups = (state.backups || []).map((backup) => {
    const donor = donors.find((d) => d.id === backup.donorId);
    return {
      ...backup,
      donorName: donor?.name || backup.donorId || 'Unknown donor',
      sizeHuman: bytesToHuman(backup.sizeBytes || 0)
    };
  });

  const jobs = [...(state.jobs || [])].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 50);

  const apiKeys = (state.apiKeys || []).map((item) => ({
    id: item.id,
    name: item.name,
    permissions: item.permissions || [],
    allowedSources: item.allowedSources || [],
    notes: item.notes || '',
    disabled: !!item.disabled,
    keyMasked: maskSecret(item.key || ''),
    createdAt: item.createdAt
  }));

  const totalBytes = donors.reduce((sum, donor) => sum + (donor.system?.totalBytes || 0), 0);
  const freeBytes = donors.reduce((sum, donor) => sum + (donor.system?.freeBytes || 0), 0);

  res.json({
    ok: true,
    settings: state.settings,
    overview: {
      donorCount: donors.length,
      onlineDonors: donors.filter((d) => d.online).length,
      backupCount: backups.length,
      pendingJobs: jobs.filter((j) => j.status === 'pending' || j.status === 'claimed').length,
      totalBytes,
      freeBytes,
      usedBytes: totalBytes - freeBytes,
      totalHuman: bytesToHuman(totalBytes),
      freeHuman: bytesToHuman(freeBytes),
      usedHuman: bytesToHuman(totalBytes - freeBytes),
      refreshIntervalMs: state.settings?.refreshIntervalMs || 120000
    },
    donors,
    backups: backups.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)),
    jobs,
    apiKeys,
    events: (state.events || []).slice(0, 50)
  });
});

export default router;

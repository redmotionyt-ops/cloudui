import { Router } from 'express';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import { Readable } from 'stream';
import { requireAdmin } from '../lib/security.js';
import { readState, updateState, getUploadsDir } from '../lib/store.js';
import { addDaysIso, bytesToHuman, getYearMonthPath, nowIso, parseCsvList, randomId, randomKey, sanitizeFileName, trimString } from '../lib/utils.js';
import { findOnlineDonor, computeDonor } from '../lib/donors.js';

const router = Router();
const upload = multer({
  dest: getUploadsDir(),
  limits: { fileSize: 20 * 1024 * 1024 * 1024 }
});

async function sha256File(filePath) {
  const crypto = await import('crypto');
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('error', reject);
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

function createBackupAndStoreJob({ draft, donorId, fileName, sizeBytes, checksum, serverId, serverName, type, reason, sourceLabel, req }) {
  const backupId = randomId('bkp');
  const stagedUploadId = randomId('stg');
  const stagedToken = randomKey('staged');
  const now = nowIso();
  const relativePath = `servers/${serverId}/${getYearMonthPath()}/${backupId}_${sanitizeFileName(fileName)}`;
  const displayName = serverName || serverId;
  const backup = {
    id: backupId,
    serverId,
    serverName: displayName,
    donorId,
    type,
    reason,
    sourceLabel,
    sizeBytes,
    checksum,
    status: 'pending_upload',
    relativePath,
    createdAt: now,
    expiresAt: addDaysIso(21)
  };

  const staged = {
    id: stagedUploadId,
    token: stagedToken,
    donorId,
    fileName,
    sizeBytes,
    checksum,
    tempPath: req.file.path,
    createdAt: now
  };

  const baseUrl = `${req.protocol}://${req.get('host')}`;

  const job = {
    id: randomId('job'),
    type: 'store_file',
    donorId,
    backupId,
    stagedUploadId,
    status: 'pending',
    createdAt: now,
    updatedAt: now,
    details: `${reason} for ${displayName}`,
    fileName,
    relativePath,
    downloadUrl: `${baseUrl}/api/donor/staged/${stagedUploadId}/download`,
    downloadHeaders: {
      'X-Staged-Token': stagedToken
    }
  };

  draft.backups.push(backup);
  draft.stagedUploads.push(staged);
  draft.jobs.push(job);

  return { backup, job };
}

router.get('/dashboard', requireAdmin, (_req, res) => {
  const state = readState();
  const timeoutDonors = (state.donors || []).map(computeDonor);
  const backups = (state.backups || []).map((backup) => {
    const donor = timeoutDonors.find((item) => item.id === backup.donorId);
    return {
      ...backup,
      donorName: donor?.name || backup.donorId,
      sizeHuman: bytesToHuman(backup.sizeBytes || 0)
    };
  });

  res.json({
    ok: true,
    settings: state.settings,
    donors: timeoutDonors,
    backups,
    jobs: state.jobs || [],
    apiKeys: state.apiKeys || [],
    events: state.events || []
  });
});

router.post('/donors', requireAdmin, (req, res) => {
  const id = trimString(req.body?.id, `dnr_${Math.random().toString(36).slice(2, 8)}`);
  const name = trimString(req.body?.name, id);
  const notes = trimString(req.body?.notes, '');
  const expectedBaseUrl = trimString(req.body?.expectedBaseUrl, '');

  const state = readState();
  if (state.donors.find((item) => item.id === id)) {
    return res.status(400).json({ ok: false, error: 'Donor id already exists' });
  }

  const donorKey = trimString(req.body?.donorKey, randomKey('donor'));
  const donor = {
    id,
    name,
    donorKey,
    notes,
    expectedBaseUrl,
    createdAt: nowIso(),
    status: 'offline',
    disabled: false,
    lastSeenAt: null,
    lastError: '',
    system: {},
    fileServer: {
      publicBaseUrl: expectedBaseUrl || '',
      port: null,
      lastHealthAt: null
    }
  };

  updateState((draft) => {
    draft.donors.push(donor);
    draft.events.unshift({
      id: randomId('evt'),
      type: 'donor',
      message: `Donor ${name} created`,
      meta: { donorId: id },
      createdAt: nowIso()
    });
    return draft;
  });

  res.json({ ok: true, donor });
});

router.put('/donors/:donorId', requireAdmin, (req, res) => {
  const state = readState();
  const donor = state.donors.find((item) => item.id === req.params.donorId);
  if (!donor) return res.status(404).json({ ok: false, error: 'Donor not found' });

  const nextState = updateState((draft) => {
    const target = draft.donors.find((item) => item.id === req.params.donorId);
    target.name = trimString(req.body?.name, target.name);
    target.notes = trimString(req.body?.notes, target.notes);
    target.expectedBaseUrl = trimString(req.body?.expectedBaseUrl, target.expectedBaseUrl || '');
    target.disabled = !!req.body?.disabled;
    if (req.body?.rotateKey) {
      target.donorKey = randomKey('donor');
    }
    return draft;
  });

  res.json({ ok: true, donor: nextState.donors.find((item) => item.id === req.params.donorId) });
});

router.delete('/donors/:donorId', requireAdmin, (req, res) => {
  const state = readState();
  const donor = state.donors.find((item) => item.id === req.params.donorId);
  if (!donor) return res.status(404).json({ ok: false, error: 'Donor not found' });

  const pending = (state.jobs || []).find((job) => job.donorId === donor.id && (job.status === 'pending' || job.status === 'claimed'));
  if (pending) {
    return res.status(400).json({ ok: false, error: 'Donor has pending jobs. Finish or clear them first.' });
  }

  updateState((draft) => {
    draft.donors = draft.donors.filter((item) => item.id !== donor.id);
    draft.backups = draft.backups.filter((item) => item.donorId !== donor.id);
    draft.events.unshift({
      id: randomId('evt'),
      type: 'donor',
      message: `Donor ${donor.name} deleted`,
      meta: { donorId: donor.id },
      createdAt: nowIso()
    });
    return draft;
  });

  res.json({ ok: true });
});

router.post('/donors/:donorId/test-access', requireAdmin, async (req, res) => {
  const state = readState();
  const donor = state.donors.find((item) => item.id === req.params.donorId);
  if (!donor) return res.status(404).json({ ok: false, error: 'Donor not found' });

  const baseUrl = donor.fileServer?.publicBaseUrl || donor.expectedBaseUrl;
  if (!baseUrl) return res.status(400).json({ ok: false, error: 'Donor has no file server URL yet' });

  try {
    const response = await fetch(`${baseUrl.replace(/\/$/, '')}/health`, {
      headers: {
        'X-Donor-Key': donor.donorKey
      }
    });

    if (!response.ok) {
      throw new Error(`Health request returned ${response.status}`);
    }

    const payload = await response.json();
    const nextState = updateState((draft) => {
      const target = draft.donors.find((item) => item.id === donor.id);
      target.fileServer = {
        ...(target.fileServer || {}),
        publicBaseUrl: payload.publicBaseUrl || target.fileServer?.publicBaseUrl || baseUrl,
        port: payload.port || target.fileServer?.port || null,
        lastHealthAt: nowIso()
      };
      target.lastError = '';
      return draft;
    });

    res.json({ ok: true, donor: nextState.donors.find((item) => item.id === donor.id), payload });
  } catch (error) {
    const nextState = updateState((draft) => {
      const target = draft.donors.find((item) => item.id === donor.id);
      target.lastError = error.message || 'Access test failed';
      return draft;
    });
    res.status(500).json({ ok: false, error: error.message, donor: nextState.donors.find((item) => item.id === donor.id) });
  }
});

router.get('/api-keys', requireAdmin, (_req, res) => {
  res.json({ ok: true, apiKeys: readState().apiKeys || [] });
});

router.post('/api-keys', requireAdmin, (req, res) => {
  const name = trimString(req.body?.name, 'Unnamed API');
  const permissions = parseCsvList(req.body?.permissions);
  const allowedSources = parseCsvList(req.body?.allowedSources);
  if (!allowedSources.length) {
    return res.status(400).json({ ok: false, error: 'Allowed source/IP/domain is required' });
  }

  const record = {
    id: randomId('api'),
    name,
    key: randomKey('fxapi'),
    notes: trimString(req.body?.notes, ''),
    permissions,
    allowedSources,
    disabled: false,
    createdAt: nowIso()
  };

  updateState((draft) => {
    draft.apiKeys.push(record);
    draft.events.unshift({
      id: randomId('evt'),
      type: 'api',
      message: `API key ${name} created`,
      meta: { apiKeyId: record.id },
      createdAt: nowIso()
    });
    return draft;
  });

  res.json({ ok: true, apiKey: record });
});

router.put('/api-keys/:apiKeyId', requireAdmin, (req, res) => {
  const state = readState();
  const target = state.apiKeys.find((item) => item.id === req.params.apiKeyId);
  if (!target) return res.status(404).json({ ok: false, error: 'API key not found' });

  const nextState = updateState((draft) => {
    const item = draft.apiKeys.find((entry) => entry.id === req.params.apiKeyId);
    item.name = trimString(req.body?.name, item.name);
    item.notes = trimString(req.body?.notes, item.notes);
    item.permissions = parseCsvList(req.body?.permissions);
    item.allowedSources = parseCsvList(req.body?.allowedSources);
    item.disabled = !!req.body?.disabled;
    if (req.body?.rotateKey) item.key = randomKey('fxapi');
    return draft;
  });

  res.json({ ok: true, apiKey: nextState.apiKeys.find((item) => item.id === req.params.apiKeyId) });
});

router.delete('/api-keys/:apiKeyId', requireAdmin, (req, res) => {
  const state = readState();
  const target = state.apiKeys.find((item) => item.id === req.params.apiKeyId);
  if (!target) return res.status(404).json({ ok: false, error: 'API key not found' });

  updateState((draft) => {
    draft.apiKeys = draft.apiKeys.filter((item) => item.id !== req.params.apiKeyId);
    draft.events.unshift({
      id: randomId('evt'),
      type: 'api',
      message: `API key ${target.name} deleted`,
      meta: { apiKeyId: target.id },
      createdAt: nowIso()
    });
    return draft;
  });

  res.json({ ok: true });
});

router.post('/backups/manual', requireAdmin, upload.single('backupFile'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ ok: false, error: 'No file uploaded' });
    const state = readState();
    const donor = findOnlineDonor(state, req.body?.donorId);
    if (!donor) return res.status(400).json({ ok: false, error: 'No online donor available' });

    const serverId = trimString(req.body?.serverId, 'manual_upload');
    const serverName = trimString(req.body?.serverName, serverId);
    const checksum = await sha256File(req.file.path);

    let created;
    updateState((draft) => {
      created = createBackupAndStoreJob({
        draft,
        donorId: donor.id,
        fileName: req.file.originalname,
        sizeBytes: req.file.size,
        checksum,
        serverId,
        serverName,
        type: trimString(req.body?.type, 'manual'),
        reason: 'Manual upload',
        sourceLabel: 'website',
        req
      });
      draft.events.unshift({
        id: randomId('evt'),
        type: 'backup',
        message: `Manual upload queued for ${serverName}`,
        meta: { backupId: created.backup.id, donorId: donor.id },
        createdAt: nowIso()
      });
      return draft;
    });

    res.json({ ok: true, backup: created.backup, job: created.job, donor });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message || 'Manual upload failed' });
  }
});

router.delete('/backups/:backupId', requireAdmin, (req, res) => {
  const state = readState();
  const backup = state.backups.find((item) => item.id === req.params.backupId);
  if (!backup) return res.status(404).json({ ok: false, error: 'Backup not found' });

  const donor = (state.donors || []).map(computeDonor).find((item) => item.id === backup.donorId);
  if (!donor?.online) return res.status(400).json({ ok: false, error: 'Assigned donor is offline' });

  const job = {
    id: randomId('job'),
    type: 'delete_file',
    donorId: donor.id,
    backupId: backup.id,
    status: 'pending',
    createdAt: nowIso(),
    updatedAt: nowIso(),
    details: `Delete backup ${backup.id}`
  };

  updateState((draft) => {
    const item = draft.backups.find((entry) => entry.id === backup.id);
    if (item) item.status = 'deleting';
    draft.jobs.push(job);
    draft.events.unshift({
      id: randomId('evt'),
      type: 'backup',
      message: `Delete queued for ${backup.serverName}`,
      meta: { backupId: backup.id, donorId: donor.id },
      createdAt: nowIso()
    });
    return draft;
  });

  res.json({ ok: true, job });
});

async function proxyBackupDownload(res, backup) {
  const state = readState();
  const donor = state.donors.find((item) => item.id === backup.donorId);
  if (!donor) return res.status(404).json({ ok: false, error: 'Donor not found' });

  const baseUrl = donor.fileServer?.publicBaseUrl || donor.expectedBaseUrl;
  if (!baseUrl) return res.status(400).json({ ok: false, error: 'Donor file server URL missing' });

  const upstream = await fetch(`${baseUrl.replace(/\/$/, '')}/files/${backup.id}/download`, {
    headers: {
      'X-Donor-Key': donor.donorKey
    }
  });

  if (!upstream.ok || !upstream.body) {
    return res.status(502).json({ ok: false, error: `Donor download failed (${upstream.status})` });
  }

  const fileName = sanitizeFileName(`${backup.serverName || backup.serverId}_${backup.id}.bin`);
  res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
  if (upstream.headers.get('content-type')) {
    res.setHeader('Content-Type', upstream.headers.get('content-type'));
  }
  if (upstream.headers.get('content-length')) {
    res.setHeader('Content-Length', upstream.headers.get('content-length'));
  }

  Readable.fromWeb(upstream.body).pipe(res);
}

router.get('/backups/:backupId/download', requireAdmin, async (req, res) => {
  try {
    const backupId = req.params.backupId;
    const state = readState();

    const backup = state.backups.find((b) => b.id === backupId);
    if (!backup) {
      return res.status(404).json({ ok: false, error: 'Backup not found' });
    }

    if (!backup.downloadUrl) {
      return res.status(400).json({ ok: false, error: 'Backup has no download source' });
    }

    const response = await fetch(backup.downloadUrl, {
      headers: backup.downloadHeaders || {}
    });

    if (!response.ok) {
      return res.status(502).json({ ok: false, error: 'Failed to fetch backup from donor' });
    }

    const fileName =
      backup.originalName ||
      backup.fileName ||
      `${backup.serverName || backup.serverId || backup.id}.zip`;

    const contentType =
      backup.mimeType ||
      response.headers.get('content-type') ||
      'application/octet-stream';

    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);

    response.body.pipe(res);
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message || 'Download failed' });
  }
});

export default router;

import { Router } from 'express';
import multer from 'multer';
import { requireApiPermission } from '../lib/security.js';
import { readState, updateState, getUploadsDir } from '../lib/store.js';
import { createDownloadToken } from '../lib/downloads.js';
import { bytesToHuman, nowIso, parseCsvList, randomId, sanitizeFileName, trimString } from '../lib/utils.js';
import { findOnlineDonor, computeDonor } from '../lib/donors.js';

const router = Router();
const upload = multer({
  dest: getUploadsDir(),
  limits: { fileSize: 20 * 1024 * 1024 * 1024 }
});

async function sha256File(filePath) {
  const crypto = await import('crypto');
  const fs = await import('fs');
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('error', reject);
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

function queueStagedBackup({ draft, donor, req, file, checksum, serverId, serverName, nodeName, reason = 'Daemon upload' }) {
  const backupId = randomId('bkp');
  const stagedUploadId = randomId('stg');
  const stagedToken = randomId('stgTok');
  const createdAt = nowIso();
  const relativePath = `servers/${serverId}/${new Date().getUTCFullYear()}/${String(new Date().getUTCMonth() + 1).padStart(2, '0')}/${backupId}_${sanitizeFileName(file.originalname)}`;

  const baseUrl = `${req.protocol}://${req.get('host')}`;

  const backup = {
    id: backupId,
    serverId,
    serverName,
    nodeName,
    donorId: donor.id,
    type: 'daemon_upload',
    reason,
    sourceLabel: 'daemon',
    sizeBytes: file.size,
    checksum,
    status: 'pending_upload',
    relativePath,
    createdAt,
    expiresAt: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000).toISOString()
  };

  draft.backups.push(backup);
  draft.stagedUploads.push({
    id: stagedUploadId,
    token: stagedToken,
    donorId: donor.id,
    fileName: file.originalname,
    sizeBytes: file.size,
    checksum,
    tempPath: file.path,
    createdAt
  });
  draft.jobs.push({
    id: randomId('job'),
    type: 'store_file',
    donorId: donor.id,
    backupId,
    stagedUploadId,
    status: 'pending',
    createdAt,
    updatedAt: createdAt,
    details: `Daemon upload for ${serverName}`,
    fileName: file.originalname,
    relativePath,
    downloadUrl: `${baseUrl}/api/donor/staged/${stagedUploadId}/download`,
    downloadHeaders: {
      'X-Staged-Token': stagedToken
    }
  });

  return backup;
}

router.post('/backups/upload', requireApiPermission('daemon.upload'), upload.single('backupFile'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ ok: false, error: 'Missing backupFile' });

    const state = readState();
    const donor = findOnlineDonor(state, req.body?.donorId);
    if (!donor) return res.status(400).json({ ok: false, error: 'No online donor available' });

    const serverId = trimString(req.body?.serverId, '');
    const serverName = trimString(req.body?.serverName, serverId || 'unknown_server');
    const nodeName = trimString(req.body?.nodeName, 'unknown_node');
    if (!serverId) return res.status(400).json({ ok: false, error: 'serverId is required' });

    const checksum = await sha256File(req.file.path);
    let backup;
    updateState((draft) => {
      backup = queueStagedBackup({
        draft,
        donor,
        req,
        file: req.file,
        checksum,
        serverId,
        serverName,
        nodeName,
        reason: trimString(req.body?.reason, 'Daemon backup')
      });
      draft.events.unshift({
        id: randomId('evt'),
        type: 'daemon',
        message: `Daemon backup queued for ${serverName}`,
        meta: { backupId: backup.id, serverId, donorId: donor.id, apiKeyId: req.apiKeyRecord.id },
        createdAt: nowIso()
      });
      return draft;
    });

    res.json({ ok: true, backup, donor });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message || 'Daemon upload failed' });
  }
});

router.get('/backups/list', requireApiPermission('daemon.list'), (req, res) => {
  const serverId = trimString(req.query?.serverId, '');
  const state = readState();

  let backups = state.backups || [];
  if (serverId) backups = backups.filter((item) => item.serverId === serverId);

  backups = backups
    .map((backup) => ({
      ...backup,
      sizeHuman: bytesToHuman(backup.sizeBytes || 0)
    }))
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  res.json({ ok: true, backups });
});

router.post('/backups/request-download', requireApiPermission('daemon.download'), (req, res) => {
  const serverId = trimString(req.body?.serverId, '');
  const backupId = trimString(req.body?.backupId, '');
  const state = readState();

  let backup;
  if (backupId) {
    backup = state.backups.find((item) => item.id === backupId);
  } else if (serverId) {
    backup = [...state.backups]
      .filter((item) => item.serverId === serverId && item.status === 'verified')
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
  }

  if (!backup) return res.status(404).json({ ok: false, error: 'Backup not found' });

  const donor = (state.donors || []).map(computeDonor).find((item) => item.id === backup.donorId);
  if (!donor?.online) return res.status(400).json({ ok: false, error: 'Backup donor is offline' });

  const token = createDownloadToken(backup.id, `daemon:${req.apiKeyRecord.id}`);
  const baseUrl = `${req.protocol}://${req.get('host')}`;

  updateState((draft) => {
    draft.events.unshift({
      id: randomId('evt'),
      type: 'daemon',
      message: `Daemon download token issued for ${backup.serverName}`,
      meta: { backupId: backup.id, apiKeyId: req.apiKeyRecord.id },
      createdAt: nowIso()
    });
    return draft;
  });

  res.json({
    ok: true,
    backup,
    downloadUrl: `${baseUrl}/api/daemon/backups/download/${backup.id}?token=${encodeURIComponent(token.token)}`,
    expiresAt: token.expiresAt
  });
});

router.get('/backups/download/:backupId', async (req, res) => {
  const tokenValue = trimString(req.query?.token, '');
  if (!tokenValue) return res.status(401).json({ ok: false, error: 'Missing download token' });

  const state = readState();
  const token = (state.downloadTokens || []).find((item) => item.token === tokenValue && item.backupId === req.params.backupId);
  if (!token) return res.status(401).json({ ok: false, error: 'Bad download token' });
  if (new Date(token.expiresAt).getTime() < Date.now()) return res.status(401).json({ ok: false, error: 'Download token expired' });

  const backup = state.backups.find((item) => item.id === req.params.backupId);
  if (!backup) return res.status(404).json({ ok: false, error: 'Backup not found' });

  const donor = state.donors.find((item) => item.id === backup.donorId);
  if (!donor) return res.status(404).json({ ok: false, error: 'Donor not found' });

  const baseUrl = donor.fileServer?.publicBaseUrl || donor.expectedBaseUrl;
  if (!baseUrl) return res.status(400).json({ ok: false, error: 'Donor file server missing' });

  try {
    const upstream = await fetch(`${baseUrl.replace(/\/$/, '')}/files/${backup.id}/download`, {
      headers: {
        'X-Donor-Key': donor.donorKey
      }
    });

    if (!upstream.ok || !upstream.body) {
      return res.status(502).json({ ok: false, error: `Donor responded with ${upstream.status}` });
    }

    res.setHeader('Content-Disposition', `attachment; filename="${sanitizeFileName(`${backup.serverName || backup.serverId}_${backup.id}.bin`)}"`);
    if (upstream.headers.get('content-type')) res.setHeader('Content-Type', upstream.headers.get('content-type'));
    if (upstream.headers.get('content-length')) res.setHeader('Content-Length', upstream.headers.get('content-length'));

    const { Readable } = await import('stream');
    Readable.fromWeb(upstream.body).pipe(res);
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message || 'Download failed' });
  }
});

router.delete('/backups/:backupId', requireApiPermission('daemon.delete'), (req, res) => {
  const state = readState();
  const backup = state.backups.find((item) => item.id === req.params.backupId);
  if (!backup) return res.status(404).json({ ok: false, error: 'Backup not found' });

  const donor = (state.donors || []).map(computeDonor).find((item) => item.id === backup.donorId);
  if (!donor?.online) return res.status(400).json({ ok: false, error: 'Assigned donor is offline' });

  const job = {
    id: randomId('job'),
    type: 'delete_file',
    donorId: donor.id,
    backupId: backup.id,
    status: 'pending',
    createdAt: nowIso(),
    updatedAt: nowIso(),
    details: `Daemon requested delete for ${backup.id}`
  };

  updateState((draft) => {
    const item = draft.backups.find((entry) => entry.id === backup.id);
    if (item) item.status = 'deleting';
    draft.jobs.push(job);
    return draft;
  });

  res.json({ ok: true, job });
});

export default router;

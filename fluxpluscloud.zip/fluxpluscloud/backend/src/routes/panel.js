import { Router } from 'express';
import { requireApiPermission } from '../lib/security.js';
import { readState } from '../lib/store.js';
import { bytesToHuman } from '../lib/utils.js';
import { computeDonor } from '../lib/donors.js';
import { createDownloadToken } from '../lib/downloads.js';

const router = Router();

router.get('/summary', requireApiPermission('panel.read'), (_req, res) => {
  const state = readState();
  const donors = (state.donors || []).map(computeDonor);
  res.json({
    ok: true,
    summary: {
      donors: donors.length,
      onlineDonors: donors.filter((item) => item.online).length,
      backups: (state.backups || []).length,
      jobs: (state.jobs || []).length
    }
  });
});

router.get('/backups', requireApiPermission('panel.read'), (req, res) => {
  const serverId = String(req.query?.serverId || '').trim();
  const backups = (readState().backups || [])
    .filter((item) => !serverId || item.serverId === serverId)
    .map((item) => ({
      ...item,
      sizeHuman: bytesToHuman(item.sizeBytes || 0)
    }))
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  res.json({ ok: true, backups });
});

router.post('/backups/download-link', requireApiPermission('panel.download'), (req, res) => {
  const backupId = String(req.body?.backupId || '').trim();
  if (!backupId) return res.status(400).json({ ok: false, error: 'backupId is required' });

  const state = readState();
  const backup = (state.backups || []).find((item) => item.id === backupId);
  if (!backup) return res.status(404).json({ ok: false, error: 'Backup not found' });

  const token = createDownloadToken(backup.id, `panel:${req.apiKeyRecord.id}`);
  const baseUrl = `${req.protocol}://${req.get('host')}`;

  res.json({
    ok: true,
    backup,
    downloadUrl: `${baseUrl}/api/daemon/backups/download/${backup.id}?token=${encodeURIComponent(token.token)}`,
    expiresAt: token.expiresAt
  });
});

export default router;

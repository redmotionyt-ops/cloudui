import { Router } from 'express';
import fs from 'fs';
import { readState, updateState } from '../lib/store.js';
import { nowIso } from '../lib/utils.js';

const router = Router();

function getDonor(req, state = readState()) {
  const donorId = String(req.body?.donorId || req.query?.donorId || '').trim();
  const donorKey = String(req.body?.donorKey || req.headers['x-donor-key'] || '').trim();

  if (!donorId || !donorKey) {
    return { code: 401, error: 'Missing donorId or donorKey' };
  }

  const donor = (state.donors || []).find((item) => item.id === donorId);
  if (!donor) return { code: 404, error: 'Donor not found' };
  if (donor.donorKey !== donorKey) return { code: 403, error: 'Bad donor key' };
  if (donor.disabled) return { code: 403, error: 'Donor disabled' };
  return { donor };
}

router.post('/register', (req, res) => {
  const state = readState();
  const match = getDonor(req, state);
  if (match.error) return res.status(match.code || 400).json({ ok: false, error: match.error });

  const now = nowIso();
  const donor = updateState((draft) => {
    const target = draft.donors.find((item) => item.id === req.body.donorId);
    target.lastSeenAt = now;
    target.system = req.body.system || target.system || {};
    target.agentVersion = req.body.agentVersion || target.agentVersion || 'unknown';
    target.fileServer = {
      publicBaseUrl: req.body.fileServer?.publicBaseUrl || target.fileServer?.publicBaseUrl || '',
      port: req.body.fileServer?.port || target.fileServer?.port || null,
      lastHealthAt: target.fileServer?.lastHealthAt || null
    };
    target.status = 'online';
    target.lastError = '';
    return draft;
  }).donors.find((item) => item.id === req.body.donorId);

  res.json({ ok: true, donor });
});

router.post('/heartbeat', (req, res) => {
  const state = readState();
  const match = getDonor(req, state);
  if (match.error) return res.status(match.code || 400).json({ ok: false, error: match.error });

  const now = nowIso();
  const donor = updateState((draft) => {
    const target = draft.donors.find((item) => item.id === req.body.donorId);
    target.lastSeenAt = now;
    target.system = req.body.system || target.system || {};
    target.agentVersion = req.body.agentVersion || target.agentVersion || 'unknown';
    target.fileServer = {
      publicBaseUrl: req.body.fileServer?.publicBaseUrl || target.fileServer?.publicBaseUrl || '',
      port: req.body.fileServer?.port || target.fileServer?.port || null,
      lastHealthAt: target.fileServer?.lastHealthAt || target.fileServer?.lastHealthAt || null
    };
    target.status = 'online';
    target.lastError = '';
    return draft;
  }).donors.find((item) => item.id === req.body.donorId);

  res.json({ ok: true, donor });
});

router.get('/jobs', (req, res) => {
  const state = readState();
  const match = getDonor(req, state);
  if (match.error) return res.status(match.code || 400).json({ ok: false, error: match.error });

  const donorId = match.donor.id;
  const jobs = (state.jobs || [])
    .filter((job) => job.donorId === donorId && (job.status === 'pending' || (job.status === 'claimed' && job.claimedBy === donorId)))
    .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));

  res.json({ ok: true, jobs });
});

router.post('/jobs/:jobId/claim', (req, res) => {
  const state = readState();
  const match = getDonor(req, state);
  if (match.error) return res.status(match.code || 400).json({ ok: false, error: match.error });

  const now = nowIso();
  const nextState = updateState((draft) => {
    const job = draft.jobs.find((item) => item.id === req.params.jobId && item.donorId === match.donor.id);
    if (!job) return draft;
    if (job.status === 'pending' || (job.status === 'claimed' && job.claimedBy === match.donor.id)) {
      job.status = 'claimed';
      job.claimedBy = match.donor.id;
      job.updatedAt = now;
    }
    return draft;
  });

  const job = nextState.jobs.find((item) => item.id === req.params.jobId);
  if (!job) return res.status(404).json({ ok: false, error: 'Job not found' });
  res.json({ ok: true, job });
});

router.post('/jobs/:jobId/complete', (req, res) => {
  const state = readState();
  const match = getDonor(req, state);
  if (match.error) return res.status(match.code || 400).json({ ok: false, error: match.error });

  const now = nowIso();

  const nextState = updateState((draft) => {
    const job = draft.jobs.find((item) => item.id === req.params.jobId && item.donorId === match.donor.id);
    if (!job) return draft;

    job.status = 'completed';
    job.updatedAt = now;
    job.details = req.body?.details || job.details;

    if (job.type === 'store_file' && job.backupId) {
      const backup = draft.backups.find((entry) => entry.id === job.backupId);
      if (backup) {
        backup.status = 'verified';
        backup.relativePath = req.body?.result?.relativePath || backup.relativePath;
        backup.sizeBytes = req.body?.result?.sizeBytes ?? backup.sizeBytes;
        backup.checksum = req.body?.result?.checksum ?? backup.checksum;
      }

      const stageIndex = (draft.stagedUploads || []).findIndex((entry) => entry.id === job.stagedUploadId);
      if (stageIndex !== -1) {
        const entry = draft.stagedUploads[stageIndex];
        try {
          if (entry?.tempPath && fs.existsSync(entry.tempPath)) {
            fs.unlinkSync(entry.tempPath);
          }
        } catch {}
        draft.stagedUploads.splice(stageIndex, 1);
      }
    }

    if (job.type === 'delete_file' && job.backupId) {
      draft.backups = draft.backups.filter((entry) => entry.id !== job.backupId);
    }

    return draft;
  });

  const job = nextState.jobs.find((item) => item.id === req.params.jobId);
  if (!job) return res.status(404).json({ ok: false, error: 'Job not found' });

  res.json({ ok: true, job });
});

router.post('/jobs/:jobId/fail', (req, res) => {
  const state = readState();
  const match = getDonor(req, state);
  if (match.error) return res.status(match.code || 400).json({ ok: false, error: match.error });

  const now = nowIso();

  const nextState = updateState((draft) => {
    const job = draft.jobs.find((item) => item.id === req.params.jobId && item.donorId === match.donor.id);
    if (!job) return draft;

    job.status = 'failed';
    job.updatedAt = now;
    job.details = req.body?.details || 'Donor reported failure';

    if (job.type === 'store_file' && job.backupId) {
      const backup = draft.backups.find((entry) => entry.id === job.backupId);
      if (backup) backup.status = 'failed';
    }

    if (job.type === 'delete_file' && job.backupId) {
      const backup = draft.backups.find((entry) => entry.id === job.backupId);
      if (backup) backup.status = 'delete_failed';
    }

    const donor = draft.donors.find((item) => item.id === match.donor.id);
    if (donor) donor.lastError = req.body?.details || 'Job failed';

    return draft;
  });

  const job = nextState.jobs.find((item) => item.id === req.params.jobId);
  if (!job) return res.status(404).json({ ok: false, error: 'Job not found' });

  res.json({ ok: true, job });
});

router.get('/staged/:stageId/download', (req, res) => {
  const state = readState();
  const staged = (state.stagedUploads || []).find((entry) => entry.id === req.params.stageId);
  if (!staged) return res.status(404).json({ ok: false, error: 'Staged upload not found' });

  const token = String(req.headers['x-staged-token'] || '');
  if (!token || token !== staged.token) return res.status(401).json({ ok: false, error: 'Bad staged token' });

  if (!fs.existsSync(staged.tempPath)) return res.status(404).json({ ok: false, error: 'Temporary file missing' });

  res.download(staged.tempPath, staged.fileName);
});

export default router;

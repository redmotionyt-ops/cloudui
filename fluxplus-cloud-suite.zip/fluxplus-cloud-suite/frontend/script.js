const state = {
  token: localStorage.getItem('flux_cloud_token') || '',
  dashboard: null,
  activeView: 'overview',
  refreshTimer: null
};

const els = {
  gate: document.getElementById('gate'),
  appShell: document.getElementById('appShell'),
  passcodeForm: document.getElementById('passcodeForm'),
  passcodeInput: document.getElementById('passcodeInput'),
  gateMessage: document.getElementById('gateMessage'),
  statusPill: document.getElementById('statusPill'),
  pageTitle: document.getElementById('pageTitle'),
  refreshLabel: document.getElementById('refreshLabel'),
  manualRefreshBtn: document.getElementById('manualRefreshBtn'),
  statDonors: document.getElementById('statDonors'),
  statOnline: document.getElementById('statOnline'),
  statBackups: document.getElementById('statBackups'),
  statJobs: document.getElementById('statJobs'),
  totalHuman: document.getElementById('totalHuman'),
  usedHuman: document.getElementById('usedHuman'),
  freeHuman: document.getElementById('freeHuman'),
  capacityBar: document.getElementById('capacityBar'),
  liveNotes: document.getElementById('liveNotes'),
  donorGrid: document.getElementById('donorGrid'),
  backupsTableBody: document.getElementById('backupsTableBody'),
  backupSearch: document.getElementById('backupSearch'),
  uploadBackupBtn: document.getElementById('uploadBackupBtn'),
  uploadBackupInput: document.getElementById('uploadBackupInput'),
  apiKeysTableBody: document.getElementById('apiKeysTableBody'),
  jobsList: document.getElementById('jobsList'),
  eventsList: document.getElementById('eventsList'),
  modalOverlay: document.getElementById('modalOverlay'),
  modalTitle: document.getElementById('modalTitle'),
  modalEyebrow: document.getElementById('modalEyebrow'),
  modalForm: document.getElementById('modalForm'),
  closeModalBtn: document.getElementById('closeModalBtn'),
  toast: document.getElementById('toast'),
  addDonorBtn: document.getElementById('addDonorBtn'),
  addApiBtn: document.getElementById('addApiBtn')
};

document.querySelectorAll('.nav-item').forEach((btn) => {
  btn.addEventListener('click', () => switchView(btn.dataset.view));
});

els.closeModalBtn.addEventListener('click', closeModal);
els.manualRefreshBtn.addEventListener('click', () => loadDashboard(true));
els.addDonorBtn.addEventListener('click', openDonorForm);
els.addApiBtn.addEventListener('click', openApiForm);

els.passcodeForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  els.gateMessage.textContent = '';
  try {
    const data = await request('/api/auth/passcode', {
      method: 'POST',
      body: JSON.stringify({ passcode: els.passcodeInput.value })
    }, false);

    state.token = data.token;
    localStorage.setItem('flux_cloud_token', data.token);
    showApp();
    await loadDashboard(true);
  } catch (error) {
    els.gateMessage.textContent = error.message;
  }
});

els.uploadBackupBtn.addEventListener('click', () => els.uploadBackupInput.click());
els.uploadBackupInput.addEventListener('change', async (event) => {
  const file = event.target.files?.[0];
  if (!file) return;
  const serverId = window.prompt('Server ID for this backup?', 'manual_server');
  if (!serverId) return;
  const serverName = window.prompt('Display server name?', serverId) || serverId;
  const donorId = window.prompt('Preferred donor ID? Leave blank for first online donor.', '') || '';
  const form = new FormData();
  form.append('backupFile', file);
  form.append('serverId', serverId);
  form.append('serverName', serverName);
  form.append('donorId', donorId);
  form.append('type', 'manual');

  try {
    showToast('Uploading backup and queuing donor job...');
    await fetchAuthorized('/api/admin/backups/manual', {
      method: 'POST',
      body: form
    }, true);
    showToast('Manual backup queued');
    await loadDashboard(true);
  } catch (error) {
    showToast(error.message);
  } finally {
    event.target.value = '';
  }
});

els.backupSearch.addEventListener('input', () => renderBackups());

els.backupsTableBody.addEventListener('click', async (event) => {
  const deleteBtn = event.target.closest('[data-delete-backup]');
  const downloadBtn = event.target.closest('[data-download-backup]');
  if (deleteBtn) {
    const backupId = deleteBtn.dataset.deleteBackup;
    if (!window.confirm(`Delete backup ${backupId}?`)) return;
    try {
      await request(`/api/admin/backups/${backupId}`, { method: 'DELETE' });
      showToast(`Delete queued for ${backupId}`);
      await loadDashboard(true);
    } catch (error) {
      showToast(error.message);
    }
  }
  if (downloadBtn) {
    const backupId = downloadBtn.dataset.downloadBackup;
    try {
      await browserDownload(backupId);
    } catch (error) {
      showToast(error.message);
    }
  }
});

els.donorGrid.addEventListener('click', async (event) => {
  const testBtn = event.target.closest('[data-test-donor]');
  const editBtn = event.target.closest('[data-edit-donor]');
  const deleteBtn = event.target.closest('[data-delete-donor]');

  if (testBtn) {
    const donorId = testBtn.dataset.testDonor;
    try {
      showToast(`Testing donor ${donorId}...`);
      await request(`/api/admin/donors/${donorId}/test-access`, { method: 'POST' });
      showToast(`${donorId} responded successfully`);
      await loadDashboard(true);
    } catch (error) {
      showToast(error.message);
    }
  }

  if (editBtn) {
    const donorId = editBtn.dataset.editDonor;
    const donor = state.dashboard?.donors?.find((item) => item.id === donorId);
    if (donor) openDonorForm(donor);
  }

  if (deleteBtn) {
    const donorId = deleteBtn.dataset.deleteDonor;
    if (!window.confirm(`Delete donor ${donorId}? Backups linked to it will also be removed.`)) return;
    try {
      await request(`/api/admin/donors/${donorId}`, { method: 'DELETE' });
      showToast(`Deleted donor ${donorId}`);
      await loadDashboard(true);
    } catch (error) {
      showToast(error.message);
    }
  }
});

els.apiKeysTableBody.addEventListener('click', async (event) => {
  const editBtn = event.target.closest('[data-edit-api]');
  const deleteBtn = event.target.closest('[data-delete-api]');
  const copyBtn = event.target.closest('[data-copy-api]');

  if (editBtn) {
    const apiId = editBtn.dataset.editApi;
    const api = state.dashboard?.apiKeys?.find((item) => item.id === apiId);
    if (api) openApiForm(api);
  }

  if (deleteBtn) {
    const apiId = deleteBtn.dataset.deleteApi;
    if (!window.confirm(`Delete API key ${apiId}?`)) return;
    try {
      await request(`/api/admin/api-keys/${apiId}`, { method: 'DELETE' });
      showToast(`Deleted API key ${apiId}`);
      await loadDashboard(true);
    } catch (error) {
      showToast(error.message);
    }
  }

  if (copyBtn) {
    const value = copyBtn.dataset.copyApi;
    await navigator.clipboard.writeText(value);
    showToast('Copied API key');
  }
});

function showApp() {
  els.gate.classList.add('hidden');
  els.appShell.classList.remove('hidden');
}

function switchView(view) {
  state.activeView = view;
  document.querySelectorAll('.nav-item').forEach((btn) => btn.classList.toggle('active', btn.dataset.view === view));
  document.querySelectorAll('.view').forEach((section) => section.classList.toggle('active', section.id === `view-${view}`));
  const titles = {
    overview: 'Overview',
    donors: 'Donors',
    backups: 'Backups',
    api: 'API Keys',
    jobs: 'Jobs',
    events: 'Events'
  };
  els.pageTitle.textContent = titles[view] || 'Overview';
}

async function request(url, options = {}, withJson = true) {
  const headers = { ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  if (withJson && !headers['Content-Type']) headers['Content-Type'] = 'application/json';

  const response = await fetch(url, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || `Request failed (${response.status})`);
  }
  return data;
}

async function fetchAuthorized(url, options = {}, isForm = false) {
  const headers = { ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  if (!isForm && !headers['Content-Type']) headers['Content-Type'] = 'application/json';

  const response = await fetch(url, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}

async function loadDashboard(silent = false) {
  try {
    const payload = await request('/api/admin/dashboard');
    state.dashboard = payload;
    renderDashboard();
    scheduleRefresh(payload?.settings?.refreshIntervalMs || 120000);
    if (!silent) showToast('Dashboard refreshed');
  } catch (error) {
    if (/admin token/i.test(error.message) || /invalid admin token/i.test(error.message)) {
      localStorage.removeItem('flux_cloud_token');
      state.token = '';
      els.appShell.classList.add('hidden');
      els.gate.classList.remove('hidden');
      els.gateMessage.textContent = 'Session expired. Enter the passcode again.';
      return;
    }
    showToast(error.message);
  }
}

function renderDashboard() {
  const payload = state.dashboard;
  if (!payload) return;

  const donors = payload.donors || [];
  const backups = payload.backups || [];
  const jobs = payload.jobs || [];
  const apiKeys = payload.apiKeys || [];
  const events = payload.events || [];

  els.statusPill.textContent = `${donors.filter((item) => item.online).length} donor(s) online`;
  els.refreshLabel.textContent = `${Math.round((payload.settings?.refreshIntervalMs || 120000) / 1000)}s live sync`;

  els.statDonors.textContent = String(donors.length);
  els.statOnline.textContent = String(donors.filter((item) => item.online).length);
  els.statBackups.textContent = String(backups.length);
  els.statJobs.textContent = String(jobs.filter((item) => item.status === 'pending' || item.status === 'claimed').length);

  const totalBytes = donors.reduce((sum, donor) => sum + (donor.system?.totalBytes || 0), 0);
  const freeBytes = donors.reduce((sum, donor) => sum + (donor.system?.freeBytes || 0), 0);
  const usedBytes = totalBytes - freeBytes;
  els.totalHuman.textContent = human(totalBytes);
  els.usedHuman.textContent = human(usedBytes);
  els.freeHuman.textContent = human(freeBytes);
  const percent = totalBytes ? Math.min(100, Math.max(0, (usedBytes / totalBytes) * 100)) : 0;
  els.capacityBar.style.width = `${percent.toFixed(1)}%`;

  els.liveNotes.innerHTML = [
    `${donors.filter((item) => item.online).length}/${donors.length} donors are online right now.`,
    `${backups.filter((item) => item.status === 'verified').length} verified backups are available.`,
    `${jobs.filter((item) => item.status === 'pending').length} job(s) are waiting for donor workers.`,
    `Website and admin UI refresh every ${Math.round((payload.settings?.refreshIntervalMs || 120000) / 1000)} seconds.`
  ].map((text) => `<div class="note-item"><strong>${text}</strong><span>Live backend data</span></div>`).join('');

  renderDonors();
  renderBackups();
  renderApiKeys(apiKeys);
  renderJobs(jobs);
  renderEvents(events);
}

function renderDonors() {
  const donors = state.dashboard?.donors || [];
  els.donorGrid.innerHTML = donors.map((donor) => {
    const used = Math.max(0, (donor.system?.totalBytes || 0) - (donor.system?.freeBytes || 0));
    return `
      <article class="donor-card">
        <div class="donor-top">
          <div>
            <div class="eyebrow">${donor.id}</div>
            <h3>${escapeHtml(donor.name)}</h3>
          </div>
          <span class="badge ${donor.online ? 'online' : 'offline'}">${donor.online ? 'Online' : 'Offline'}</span>
        </div>

        <div class="meta-grid">
          <div class="meta-box">
            <span>Total</span>
            <strong>${human(donor.system?.totalBytes || 0)}</strong>
          </div>
          <div class="meta-box">
            <span>Free</span>
            <strong>${human(donor.system?.freeBytes || 0)}</strong>
          </div>
          <div class="meta-box">
            <span>Used</span>
            <strong>${human(used)}</strong>
          </div>
          <div class="meta-box">
            <span>Last seen</span>
            <strong>${donor.lastSeenAt ? new Date(donor.lastSeenAt).toLocaleString() : 'Never'}</strong>
          </div>
        </div>

        <div class="note-item" style="margin-top:16px;">
          <strong>File server</strong>
          <span>${escapeHtml(donor.fileServer?.publicBaseUrl || donor.expectedBaseUrl || 'Not set yet')}</span>
        </div>

        ${donor.lastError ? `<div class="note-item" style="margin-top:12px;"><strong>Last error</strong><span>${escapeHtml(donor.lastError)}</span></div>` : ''}

        <div class="card-actions">
          <button class="small-btn accent" data-test-donor="${donor.id}">Test</button>
          <button class="small-btn" data-edit-donor="${donor.id}">Edit</button>
          <button class="small-btn danger" data-delete-donor="${donor.id}">Delete</button>
        </div>
      </article>
    `;
  }).join('') || '<div class="note-item"><strong>No donors yet.</strong><span>Add a donor from the button above, then place its donorKey in the donor app config.</span></div>';
}

function renderBackups() {
  const allBackups = state.dashboard?.backups || [];
  const search = (els.backupSearch.value || '').trim().toLowerCase();
  const backups = allBackups.filter((item) => {
    if (!search) return true;
    return [item.id, item.serverId, item.serverName, item.donorName].filter(Boolean).some((part) => String(part).toLowerCase().includes(search));
  });

  els.backupsTableBody.innerHTML = backups.map((backup) => `
    <tr>
      <td>${backup.id}</td>
      <td>${escapeHtml(backup.serverName || backup.serverId)}</td>
      <td>${escapeHtml(backup.donorName || backup.donorId || 'Unknown')}</td>
      <td>${escapeHtml(backup.type || 'unknown')}</td>
      <td>${escapeHtml(backup.sizeHuman || human(backup.sizeBytes || 0))}</td>
      <td><span class="tag ${backup.status}">${escapeHtml(backup.status)}</span></td>
      <td>${new Date(backup.createdAt).toLocaleString()}</td>
      <td>
        <button class="mini-btn accent" data-download-backup="${backup.id}">Download</button>
        <button class="mini-btn danger" data-delete-backup="${backup.id}">Delete</button>
      </td>
    </tr>
  `).join('') || '<tr><td colspan="8">No backups found.</td></tr>';
}

function renderApiKeys(apiKeys) {
  els.apiKeysTableBody.innerHTML = apiKeys.map((item) => `
    <tr>
      <td>${escapeHtml(item.name)}</td>
      <td>${item.key ? `<code>${escapeHtml(item.key)}</code>` : `<code>${escapeHtml(item.keyMasked || 'hidden')}</code>`}</td>
      <td>${escapeHtml((item.allowedSources || []).join(', '))}</td>
      <td>${escapeHtml((item.permissions || []).join(', '))}</td>
      <td>
        ${item.key ? `<button class="mini-btn accent" data-copy-api="${item.key}">Copy</button>` : ''}
        <button class="mini-btn" data-edit-api="${item.id}">Edit</button>
        <button class="mini-btn danger" data-delete-api="${item.id}">Delete</button>
      </td>
    </tr>
  `).join('') || '<tr><td colspan="5">No API keys yet.</td></tr>';
}

function renderJobs(jobs) {
  els.jobsList.innerHTML = jobs.map((job) => `
    <article class="job-card">
      <strong>${escapeHtml(job.type)} <span class="tag ${job.status}">${escapeHtml(job.status)}</span></strong>
      <div class="job-meta">
        <span>Job: ${job.id}</span>
        <span>Donor: ${job.donorId || 'n/a'}</span>
        <span>Backup: ${job.backupId || 'n/a'}</span>
        <span>Updated: ${job.updatedAt ? new Date(job.updatedAt).toLocaleString() : 'n/a'}</span>
      </div>
      <div class="job-meta"><span>${escapeHtml(job.details || 'No details')}</span></div>
    </article>
  `).join('') || '<div class="note-item"><strong>No jobs yet.</strong><span>Queued donor work will appear here.</span></div>';
}

function renderEvents(events) {
  els.eventsList.innerHTML = events.map((event) => `
    <article class="event-card">
      <strong>${escapeHtml(event.message)}</strong>
      <div class="event-meta">
        <span>${escapeHtml(event.type)}</span>
        <span>${new Date(event.createdAt).toLocaleString()}</span>
      </div>
    </article>
  `).join('') || '<div class="note-item"><strong>No events yet.</strong><span>Actions from the backend will show up here.</span></div>';
}

function openDonorForm(donor = null) {
  const editing = !!donor;
  openModal({
    eyebrow: 'Donor',
    title: editing ? `Edit donor ${donor.id}` : 'Add donor',
    html: `
      <label>Donor ID</label>
      <input name="id" value="${editing ? escapeAttr(donor.id) : ''}" ${editing ? 'disabled' : ''} placeholder="dnr_home_01" />
      <label>Name</label>
      <input name="name" value="${editing ? escapeAttr(donor.name) : ''}" placeholder="Primary Home Donor" />
      <label>Expected file server URL</label>
      <input name="expectedBaseUrl" value="${editing ? escapeAttr(donor.expectedBaseUrl || donor.fileServer?.publicBaseUrl || '') : ''}" placeholder="http://your-public-host:4310" />
      <label>Notes</label>
      <textarea name="notes" placeholder="4TB storage donor for backups">${editing ? escapeHtml(donor.notes || '') : ''}</textarea>
      ${editing ? `
        <label><input type="checkbox" name="disabled" ${donor.disabled ? 'checked' : ''} /> Disable donor</label>
        <label><input type="checkbox" name="rotateKey" /> Rotate donor key</label>
      ` : ''}
      <button type="submit">${editing ? 'Save donor' : 'Create donor'}</button>
    `,
    onSubmit: async (formData) => {
      const payload = Object.fromEntries(formData.entries());
      payload.disabled = formData.get('disabled') === 'on';
      payload.rotateKey = formData.get('rotateKey') === 'on';

      const result = editing
        ? await request(`/api/admin/donors/${donor.id}`, { method: 'PUT', body: JSON.stringify(payload) })
        : await request('/api/admin/donors', { method: 'POST', body: JSON.stringify(payload) });

      closeModal();
      await loadDashboard(true);

      if (!editing && result?.donor?.donorKey) {
        await navigator.clipboard.writeText(result.donor.donorKey);
        showToast(`Donor created. donorKey copied: ${result.donor.donorKey}`);
      } else {
        showToast('Donor saved');
      }
    }
  });
}

function openApiForm(apiKey = null) {
  const editing = !!apiKey;
  openModal({
    eyebrow: 'API key',
    title: editing ? `Edit API key ${apiKey.name}` : 'Create API key',
    html: `
      <label>Name</label>
      <input name="name" value="${editing ? escapeAttr(apiKey.name) : ''}" placeholder="Daemon Tokyo" />
      <label>Allowed server domain/IP (comma separated)</label>
      <textarea name="allowedSources" placeholder="node-jp-01.fluxplus.in, 203.0.113.10">${editing ? escapeHtml((apiKey.allowedSources || []).join(', ')) : ''}</textarea>
      <label>Permissions (comma separated)</label>
      <textarea name="permissions" placeholder="daemon.upload, daemon.download, daemon.list, panel.read">${editing ? escapeHtml((apiKey.permissions || []).join(', ')) : ''}</textarea>
      <label>Notes</label>
      <textarea name="notes" placeholder="Used by the custom daemon on the Japan node">${editing ? escapeHtml(apiKey.notes || '') : ''}</textarea>
      ${editing ? `
        <label><input type="checkbox" name="disabled" ${apiKey.disabled ? 'checked' : ''} /> Disable API key</label>
        <label><input type="checkbox" name="rotateKey" /> Rotate API key</label>
      ` : ''}
      <button type="submit">${editing ? 'Save API key' : 'Create API key'}</button>
    `,
    onSubmit: async (formData) => {
      const payload = Object.fromEntries(formData.entries());
      payload.disabled = formData.get('disabled') === 'on';
      payload.rotateKey = formData.get('rotateKey') === 'on';

      const result = editing
        ? await request(`/api/admin/api-keys/${apiKey.id}`, { method: 'PUT', body: JSON.stringify(payload) })
        : await request('/api/admin/api-keys', { method: 'POST', body: JSON.stringify(payload) });

      closeModal();
      await loadDashboard(true);

      const rawKey = result?.apiKey?.key;
      if (rawKey) {
        await navigator.clipboard.writeText(rawKey);
        showToast(`API key ready and copied: ${rawKey}`);
      } else {
        showToast('API key saved');
      }
    }
  });
}

function openModal({ eyebrow, title, html, onSubmit }) {
  els.modalEyebrow.textContent = eyebrow;
  els.modalTitle.textContent = title;
  els.modalForm.innerHTML = html;
  els.modalOverlay.classList.remove('hidden');

  const submitHandler = async (event) => {
    event.preventDefault();
    const formData = new FormData(els.modalForm);
    try {
      await onSubmit(formData);
    } catch (error) {
      showToast(error.message);
    }
  };

  els.modalForm.onsubmit = submitHandler;
}

function closeModal() {
  els.modalOverlay.classList.add('hidden');
  els.modalForm.innerHTML = '';
  els.modalForm.onsubmit = null;
}

async function browserDownload(backupId) {
  showToast(`Preparing ${backupId}...`);
  const response = await fetch(`/api/admin/backups/${backupId}/download`, {
    headers: {
      Authorization: `Bearer ${state.token}`
    }
  });

  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error || `Download failed (${response.status})`);
  }

  const blob = await response.blob();
  const disposition = response.headers.get('content-disposition') || '';
  const match = disposition.match(/filename="([^"]+)"/i);
  const fileName = match?.[1] || `${backupId}.bin`;

  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
  showToast(`Download started for ${backupId}`);
}

function scheduleRefresh(ms = 120000) {
  clearTimeout(state.refreshTimer);
  state.refreshTimer = setTimeout(() => loadDashboard(true), ms);
}

function showToast(message) {
  els.toast.textContent = message;
  els.toast.classList.remove('hidden');
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => els.toast.classList.add('hidden'), 3200);
}

function human(bytes) {
  const value = Number(bytes) || 0;
  if (value < 1024) return `${value} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let current = value / 1024;
  let index = 0;
  while (current >= 1024 && index < units.length - 1) {
    current /= 1024;
    index += 1;
  }
  return `${current.toFixed(current >= 100 ? 0 : current >= 10 ? 1 : 2)} ${units[index]}`;
}

function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function escapeAttr(value = '') {
  return escapeHtml(value);
}

(function init() {
  if (state.token) {
    showApp();
    loadDashboard(true);
  }
})();

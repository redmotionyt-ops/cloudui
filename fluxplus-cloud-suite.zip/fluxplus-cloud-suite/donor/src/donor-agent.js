import { logger } from './logger.js';

export class DonorAgent {
  constructor({ config, api, storage }) {
    this.config = config;
    this.api = api;
    this.storage = storage;
    this.jobLoop = null;
    this.heartbeatLoop = null;
    this.running = false;
  }

  systemSnapshot() {
    const disk = this.storage.getDiskStats();
    return {
      totalBytes: disk.totalBytes,
      freeBytes: disk.freeBytes,
      platform: process.platform,
      hostname: process.env.COMPUTERNAME || process.env.HOSTNAME || 'unknown-host'
    };
  }

  async register() {
    const payload = {
      system: this.systemSnapshot(),
      agentVersion: '1.0.0',
      fileServer: {
        publicBaseUrl: this.config.publicBaseUrl,
        port: this.config.fileServerPort
      }
    };
    await this.api.register(payload);
    logger.info('Donor registered successfully');
  }

  async heartbeat() {
    await this.api.heartbeat({
      system: this.systemSnapshot(),
      agentVersion: '1.0.0',
      fileServer: {
        publicBaseUrl: this.config.publicBaseUrl,
        port: this.config.fileServerPort
      }
    });
    logger.info('Heartbeat sent');
  }

  summarizeResult(result) {
    if (!result) return 'Job finished';
    if (result.removed) return 'File removed';
    if (result.fileCount !== undefined) return `Integrity scan complete. Files: ${result.fileCount}`;
    if (result.sizeBytes !== undefined) return `Stored ${result.sizeBytes} bytes`;
    return 'Job finished';
  }

  async runJob(job) {
    logger.info(`Running job ${job.id}`, { type: job.type, backupId: job.backupId });
    let result = null;

    if (job.type === 'store_file') {
      result = await this.storage.storeFromJob(job);
    } else if (job.type === 'delete_file') {
      result = this.storage.deleteBackup(job.backupId);
    } else if (job.type === 'integrity_scan') {
      result = this.storage.integrityScan();
    } else {
      throw new Error(`Unsupported job type: ${job.type}`);
    }

    await this.api.completeJob(job.id, this.summarizeResult(result), result);
    logger.info(`Completed job ${job.id}`);
  }

  async pollJobs() {
    const { jobs } = await this.api.getJobs();
    if (!jobs?.length) return;

    for (const job of jobs) {
      try {
        await this.api.claimJob(job.id);
        await this.runJob(job);
      } catch (error) {
        logger.error(`Job ${job.id} failed`, error.message);
        try {
          await this.api.failJob(job.id, error.message || 'Job failed');
        } catch (secondError) {
          logger.error(`Could not report failure for ${job.id}`, secondError.message);
        }
      }
    }
  }

  async start() {
    if (this.running) return;
    this.running = true;

    await this.register();
    await this.heartbeat();

    this.jobLoop = setInterval(() => {
      this.pollJobs().catch((error) => logger.error('Polling failed', error.message));
    }, this.config.pollIntervalMs);

    this.heartbeatLoop = setInterval(() => {
      this.heartbeat().catch((error) => logger.error('Heartbeat failed', error.message));
    }, this.config.heartbeatIntervalMs);

    logger.info('Donor agent started');
  }
}

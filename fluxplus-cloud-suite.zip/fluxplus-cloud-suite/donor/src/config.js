import fs from 'fs';
import path from 'path';

const CONFIG_PATH = path.resolve(process.cwd(), 'config.json');

export function loadConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    throw new Error('config.json not found. Copy config.example.json to config.json first.');
  }

  const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  const required = ['cloudBaseUrl', 'donorId', 'donorKey', 'storageRoot', 'fileServerPort', 'publicBaseUrl'];
  for (const key of required) {
    if (!config[key]) {
      throw new Error(`Missing required config field: ${key}`);
    }
  }

  config.pollIntervalMs = Number(config.pollIntervalMs || 20000);
  config.heartbeatIntervalMs = Number(config.heartbeatIntervalMs || 60000);
  return config;
}

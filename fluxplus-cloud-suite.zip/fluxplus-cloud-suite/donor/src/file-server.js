import http from 'http';
import fs from 'fs';
import path from 'path';
import { logger } from './logger.js';

export function startFileServer(config, storage) {
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (req.headers['x-donor-key'] !== config.donorKey) {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: 'Bad donor key' }));
      return;
    }

    if (req.method === 'GET' && url.pathname === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        ok: true,
        donorId: config.donorId,
        publicBaseUrl: config.publicBaseUrl,
        port: config.fileServerPort,
        time: new Date().toISOString()
      }));
      return;
    }

    const match = url.pathname.match(/^\/files\/([^/]+)\/download$/);
    if (req.method === 'GET' && match) {
      const backupId = decodeURIComponent(match[1]);
      const file = storage.getFileByBackupId(backupId);
      if (!file || !fs.existsSync(file.absPath)) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: 'File not found' }));
        return;
      }

      res.writeHead(200, {
        'Content-Type': 'application/octet-stream',
        'Content-Length': file.sizeBytes,
        'Content-Disposition': `attachment; filename="${path.basename(file.relativePath)}"`
      });
      fs.createReadStream(file.absPath).pipe(res);
      return;
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: false, error: 'Not found' }));
  });

  server.listen(config.fileServerPort, () => {
    logger.info(`Donor file server listening on ${config.fileServerPort}`);
  });

  return server;
}

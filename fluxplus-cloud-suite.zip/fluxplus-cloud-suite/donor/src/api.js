export class DonorApi {
  constructor(config) {
    this.baseUrl = config.cloudBaseUrl.replace(/\/$/, '');
    this.donorId = config.donorId;
    this.donorKey = config.donorKey;
  }

  async request(path, options = {}) {
    const headers = {
      ...(options.headers || {}),
      'Content-Type': options.body instanceof FormData ? undefined : (options.headers?.['Content-Type'] || 'application/json'),
      'X-Donor-Key': this.donorKey
    };

    if (headers['Content-Type'] === undefined) delete headers['Content-Type'];

    const response = await fetch(`${this.baseUrl}${path}`, {
      ...options,
      headers
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.error || `Request failed (${response.status})`);
    }
    return data;
  }

  register(payload) {
    return this.request('/api/donor/register', {
      method: 'POST',
      body: JSON.stringify({
        donorId: this.donorId,
        donorKey: this.donorKey,
        ...payload
      })
    });
  }

  heartbeat(payload) {
    return this.request('/api/donor/heartbeat', {
      method: 'POST',
      body: JSON.stringify({
        donorId: this.donorId,
        donorKey: this.donorKey,
        ...payload
      })
    });
  }

  getJobs() {
    return this.request(`/api/donor/jobs?donorId=${encodeURIComponent(this.donorId)}`);
  }

  claimJob(jobId) {
    return this.request(`/api/donor/jobs/${jobId}/claim`, {
      method: 'POST',
      body: JSON.stringify({
        donorId: this.donorId,
        donorKey: this.donorKey
      })
    });
  }

  completeJob(jobId, details, result = null) {
    return this.request(`/api/donor/jobs/${jobId}/complete`, {
      method: 'POST',
      body: JSON.stringify({
        donorId: this.donorId,
        donorKey: this.donorKey,
        details,
        result
      })
    });
  }

  failJob(jobId, details) {
    return this.request(`/api/donor/jobs/${jobId}/fail`, {
      method: 'POST',
      body: JSON.stringify({
        donorId: this.donorId,
        donorKey: this.donorKey,
        details
      })
    });
  }
}

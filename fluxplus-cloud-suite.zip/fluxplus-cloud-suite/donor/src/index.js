import { loadConfig } from './config.js';
import { logger } from './logger.js';
import { DonorApi } from './api.js';
import { Storage } from './storage.js';
import { DonorAgent } from './donor-agent.js';
import { startFileServer } from './file-server.js';

async function main() {
  try {
    const config = loadConfig();
    const api = new DonorApi(config);
    const storage = new Storage(config);

    startFileServer(config, storage);

    const agent = new DonorAgent({ config, api, storage });
    await agent.start();
  } catch (error) {
    logger.error('Startup failed', error.message);
    process.exit(1);
  }
}

main();

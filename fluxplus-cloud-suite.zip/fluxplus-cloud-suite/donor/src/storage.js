import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { pipeline } from 'stream/promises';

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

export class Storage {
  constructor(config) {
    this.root = path.resolve(process.cwd(), config.storageRoot);
    this.metadataPath = path.join(this.root, 'metadata.json');
    ensureDir(this.root);
    this.meta = this.readMeta();
  }

  readMeta() {
    if (!fs.existsSync(this.metadataPath)) {
      fs.writeFileSync(this.metadataPath, JSON.stringify({ files: [] }, null, 2));
    }
    return JSON.parse(fs.readFileSync(this.metadataPath, 'utf8'));
  }

  writeMeta() {
    fs.writeFileSync(this.metadataPath, JSON.stringify(this.meta, null, 2));
  }

  getDiskStats() {
    const stats = fs.statfsSync(this.root);
    const blockSize = Number(stats.bsize || 0);
    const totalBytes = blockSize * Number(stats.blocks || 0);
    const freeBytes = blockSize * Number(stats.bavail || 0);
    return { totalBytes, freeBytes };
  }

  async downloadToFile(downloadUrl, headers, targetPath) {
    const response = await fetch(downloadUrl, { headers: headers || {} });
    if (!response.ok || !response.body) {
      throw new Error(`Download request failed (${response.status})`);
    }

    ensureDir(path.dirname(targetPath));
    const writeStream = fs.createWriteStream(targetPath);
    await pipeline(response.body, writeStream);
  }

  checksum(filePath) {
    return new Promise((resolve, reject) => {
      const hash = crypto.createHash('sha256');
      const stream = fs.createReadStream(filePath);
      stream.on('data', (chunk) => hash.update(chunk));
      stream.on('error', reject);
      stream.on('end', () => resolve(hash.digest('hex')));
    });
  }

  async storeFromJob(job) {
    const relativePath = job.relativePath || `${job.backupId}.bin`;
    const absPath = path.join(this.root, relativePath);
    await this.downloadToFile(job.downloadUrl, job.downloadHeaders, absPath);

    const sizeBytes = fs.statSync(absPath).size;
    const checksum = await this.checksum(absPath);

    this.meta.files = this.meta.files.filter((entry) => entry.backupId !== job.backupId);
    this.meta.files.push({
      backupId: job.backupId,
      relativePath,
      sizeBytes,
      checksum,
      updatedAt: new Date().toISOString(),
      absPath
    });
    this.writeMeta();

    return { relativePath, sizeBytes, checksum };
  }

  deleteBackup(backupId) {
    const entry = this.meta.files.find((item) => item.backupId === backupId);
    if (!entry) {
      return { removed: false };
    }

    if (fs.existsSync(entry.absPath)) {
      fs.unlinkSync(entry.absPath);
    }

    this.meta.files = this.meta.files.filter((item) => item.backupId !== backupId);
    this.writeMeta();
    return { removed: true };
  }

  getFileByBackupId(backupId) {
    return this.meta.files.find((item) => item.backupId === backupId) || null;
  }

  integrityScan() {
    const missing = [];
    for (const entry of this.meta.files) {
      if (!fs.existsSync(entry.absPath)) {
        missing.push(entry.backupId);
      }
    }
    return { fileCount: this.meta.files.length, missing };
  }
}

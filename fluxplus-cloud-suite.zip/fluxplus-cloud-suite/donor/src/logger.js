export function log(level, message, meta = null) {
  const timestamp = new Date().toISOString();
  const suffix = meta ? ` ${typeof meta === 'string' ? meta : JSON.stringify(meta)}` : '';
  console.log(`[${timestamp}] [${level}] ${message}${suffix}`);
}

export const logger = {
  info(message, meta) {
    log('INFO', message, meta);
  },
  warn(message, meta) {
    log('WARN', message, meta);
  },
  error(message, meta) {
    log('ERROR', message, meta);
  }
};

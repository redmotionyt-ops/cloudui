# Flux+ Donor Agent

## Setup

1. Create a donor in the cloud UI.
2. Copy the generated `donorKey`.
3. Copy `config.example.json` to `config.json`.
4. Paste the donor values.
5. Run:

```bash
npm start
```

## Important config

- `cloudBaseUrl` → cloud backend URL
- `donorId` → donor record ID from the website
- `donorKey` → generated donor key
- `storageRoot` → folder where backups are stored
- `fileServerPort` → local donor file server port
- `publicBaseUrl` → URL the cloud backend can use to reach this donor file server

If the backend is on a VPS, `publicBaseUrl` must be reachable by that VPS.

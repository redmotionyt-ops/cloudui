import { Router } from 'express';
import { signAdminToken, requireAdmin } from '../lib/security.js';

const router = Router();

router.post('/passcode', (req, res) => {
  const passcode = String(req.body?.passcode || '');
  const expected = process.env.ADMIN_PASSCODE || 'Fluxcloudadmin112233445';

  if (passcode !== expected) {
    return res.status(401).json({ ok: false, error: 'Wrong passcode' });
  }

  return res.json({
    ok: true,
    token: signAdminToken(),
    refreshIntervalMs: 120000
  });
});

router.get('/me', requireAdmin, (_req, res) => {
  res.json({ ok: true, role: 'admin' });
});

export default router;
